# Smart Campus AI — Decision Support System
## AL2002 · Spring 2026 · Capstone Project

---

## Project Structure

```
smart_campus/
├── app.py                    ← Flask main server (entry point)
├── requirements.txt
├── modules/
│   ├── preprocessor.py       ← Module 1: Input & Preprocessing
│   ├── router.py             ← Module 2: Request Router
│   ├── ann.py                ← Module 3: ANN (Perceptron + MLP)
│   ├── logic_kb.py           ← Module 4: Logic / Knowledge Base (FOL)
│   ├── csp_scheduler.py      ← Module 5: CSP Scheduler
│   ├── search.py             ← Module 6: Search & Navigation (BFS/UCS/A*)
│   └── response_builder.py  ← Module 7: Final Response Layer
└── static/
    └── index.html            ← Frontend UI
```

---

## How to Run

### 1. Install dependencies
```bash
pip install flask
```

### 2. Start the server
```bash
cd smart_campus
python app.py
```

### 3. Open the frontend
Open your browser and go to:
```
http://localhost:5000
```

---

## Request Types & Pipelines

| Request Type            | Pipeline                              |
|-------------------------|---------------------------------------|
| Navigation_Only         | Preprocessing → Router → Search       |
| Eligibility_Check       | Preprocessing → Router → Logic/KB     |
| Booking_or_Scheduling   | → Logic/KB → CSP → (Search)          |
| Urgent_Service_Request  | → ANN → Logic/KB → CSP → (Search)    |
| Full_Service_Request    | → ANN → Logic/KB → CSP → Search      |

---

## ANN Feature Vector (fixed order)

```
[Role, RequestType, Severity, TimeSensitivity, CrowdLevel, Distance, Eligibility]
```

- **Perceptron**: binary → urgent / not_urgent
- **MLP**: multiclass → low / normal / high / urgent

---

## Knowledge Base Facts (examples)

- `Student(Ali)`, `Instructor(DrKhan, AI)`, `Teaches(DrKhan, AI)`
- `Enrolled(Ali, AI)`, `Completed(Ali, ProgrammingFundamentals)`

## FOL Rules

- R1: `Teaches(x, AI) → Instructor(x, AI)`
- R2: `Instructor(x, AI) → UsesLab(x, Lab1)`
- R3: `Enrolled(x, AI) → UsesLab(x, Lab1)`
- R4: `Student(x) ∧ Completed(x, PF) → Eligible(x, AI)`
- R5: `Enrolled(x, AI) → Eligible(x, AI_Lab_Support)`

---

## Search Algorithms

- **BFS** — unweighted shortest path
- **A*** — weighted + heuristic (default operational)
- **UCS** — weighted fallback (no heuristic)
- DFS, DLS, IDS, Bidirectional BFS, Greedy, RBFS — academic comparison

---

## Evaluation Rubric Coverage

| Component                    | Marks | Module              |
|------------------------------|-------|---------------------|
| Input & Preprocessing        | 10    | preprocessor.py     |
| ANN Priority Prediction      | 20    | ann.py              |
| Logic / Knowledge Base       | 20    | logic_kb.py         |
| CSP Scheduler                | 15    | csp_scheduler.py    |
| Search Navigation            | 15    | search.py           |
| Final Response & Integration | 10    | response_builder.py + app.py |
| Documentation & Code Quality | 10    | README + comments   |

---

## Submission Format
```
23F-XXXX_23F-XXXX_23F-XXXX_Project.zip
```
Include: all source code + project report (PDF) with screenshots.
