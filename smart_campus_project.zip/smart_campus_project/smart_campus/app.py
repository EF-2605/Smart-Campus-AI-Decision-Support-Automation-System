"""
Smart Campus AI Decision Support and Automation System
Main Flask Application Entry Point
Integrates all AI modules: Preprocessing, Router, ANN, Logic/KB, CSP, Search, Final Response
"""

from flask import Flask, request, jsonify, send_from_directory
import os

from modules.preprocessor import preprocess_request
from modules.router import route_request
from modules.ann import predict_priority
from modules.logic_kb import check_logic
from modules.csp_scheduler import assign_slot
from modules.search import find_route
from modules.response_builder import build_final_response

# ─────────────────────────────────────────
app = Flask(__name__, static_folder="static")
# ─────────────────────────────────────────


@app.route("/")
def index():
    """Serve the frontend HTML file."""
    return send_from_directory("static", "index.html")


@app.route("/api/process", methods=["POST"])
def process_request():
    """
    Main pipeline endpoint.
    Accepts a raw request JSON from frontend, runs it through the full AI pipeline,
    and returns a structured final response.
    """
    try:
        raw_input = request.get_json()
        if not raw_input:
            return jsonify({"error": "No JSON body received."}), 400

        # ── Step 1: Preprocessing ──────────────────────────────────────────
        req, prep_error = preprocess_request(raw_input)
        if prep_error:
            return jsonify({"error": prep_error, "stage": "preprocessing"}), 422

        # ── Step 2: Router ────────────────────────────────────────────────
        pipeline = route_request(req)

        # ── Step 3–6: Execute selected pipeline ───────────────────────────
        priority_out  = None
        logic_out     = None
        csp_out       = None
        search_out    = None
        early_reject  = False

        if pipeline["needs_ann"]:
            priority_out = predict_priority(req)

        if pipeline["needs_logic"]:
            logic_out = check_logic(req)
            # Gate: reject before CSP if not allowed (except pure eligibility queries)
            if req["request_type"] != "Eligibility_Check":
                if not logic_out.get("allowed", False):
                    early_reject = True

        if not early_reject:
            if pipeline["needs_csp"]:
                csp_out = assign_slot(req)

            if pipeline["needs_search"]:
                if req["request_type"] == "Navigation_Only":
                    destination = req.get("destination", "")
                else:
                    destination = csp_out.get("assigned_room", "") if csp_out else ""
                source = req.get("current_location", "")
                if source and destination:
                    search_out = find_route(source, destination)

        # ── Step 7: Final Response ─────────────────────────────────────────
        final = build_final_response(
            req=req,
            pipeline=pipeline,
            priority_out=priority_out,
            logic_out=logic_out,
            csp_out=csp_out,
            search_out=search_out,
            early_reject=early_reject,
        )

        return jsonify(final), 200

    except Exception as e:
        return jsonify({"error": str(e), "stage": "server"}), 500


@app.route("/api/campus_graph", methods=["GET"])
def campus_graph():
    """Return the campus graph nodes for the frontend dropdown menus."""
    from modules.search import CAMPUS_NODES
    return jsonify({"nodes": CAMPUS_NODES})


if __name__ == "__main__":
    app.run(debug=True, port=5000)
