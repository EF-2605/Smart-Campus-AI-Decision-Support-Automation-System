"""
Module: ANN Priority Prediction
────────────────────────────────
Responsibility:
  - Encode request features into a numeric feature vector (fixed order per spec)
  - Run a Perceptron (binary: urgent vs not_urgent)
  - Run a manually implemented MLP (multiclass: low / normal / high / urgent)
  - Return both predictions plus a softmax confidence score

Feature order (fixed — must match across all modules):
  [Role, RequestType, Severity, TimeSensitivity, CrowdLevel, Distance, Eligibility]

ANN does NOT grant or deny access — only predicts priority.
"""

import math

# ── Encoding tables (from project spec) ──────────────────────────────────────
ROLE_ENCODING = {"student": 0, "instructor": 1, "staff": 2}
REQUEST_TYPE_ENCODING = {
    "AI_Lab_Support": 0,
    "Viva_Scheduling": 1,
    "Access_Request": 2,
    "Maintenance": 3,
    "Emergency_Help": 4,
}
PRIORITY_LABELS = ["low", "normal", "high", "urgent"]   # indices 0-3

# ─────────────────────────────────────────────────────────────────────────────
# Perceptron weights  [Role, ReqType, Severity, TimeSens, Crowd, Distance, Eligibility, Bias]
# Trained heuristically to fire (urgent) when severity+time_sensitivity are high
# ─────────────────────────────────────────────────────────────────────────────
PERCEPTRON_WEIGHTS = [0.05, 0.10, 0.45, 0.40, 0.15, -0.05, -0.10]
PERCEPTRON_BIAS    = -4.20    # threshold bias

# ─────────────────────────────────────────────────────────────────────────────
# MLP weights — 2 hidden layers: 4 neurons → 3 neurons → 4 output classes
# Designed heuristically; real training would use backprop on labelled data.
# ─────────────────────────────────────────────────────────────────────────────
# Hidden layer 1: shape (7 inputs → 4 neurons)
W1 = [
    # each row = weights for one hidden neuron
    [ 0.30,  0.10,  0.55,  0.50,  0.20, -0.10,  0.05],  # h1_1 — severity-sensitive
    [ 0.10,  0.20,  0.30,  0.55,  0.25, -0.05,  0.00],  # h1_2 — time-sensitive
    [ 0.20,  0.15,  0.25,  0.30,  0.50,  0.10, -0.10],  # h1_3 — crowd/role
    [ 0.05,  0.30,  0.10,  0.15,  0.10,  0.40,  0.20],  # h1_4 — distance/type
]
B1 = [-2.10, -2.30, -1.90, -1.50]

# Hidden layer 2: shape (4 → 3 neurons)
W2 = [
    [ 0.60,  0.40, -0.20,  0.10],   # h2_1
    [ 0.20,  0.60,  0.40, -0.10],   # h2_2
    [-0.10,  0.20,  0.50,  0.60],   # h2_3
]
B2 = [-0.80, -0.80, -0.70]

# Output layer: shape (3 → 4 classes)
W3 = [
    [-0.80,  0.10,  0.10],   # low
    [ 0.10, -0.80,  0.10],   # normal
    [ 0.20,  0.40, -0.30],   # high
    [ 0.50,  0.30,  0.70],   # urgent
]
B3 = [0.50, 0.20, -0.10, -0.40]


# ── Activation functions ──────────────────────────────────────────────────────

def _relu(x: float) -> float:
    return max(0.0, x)

def _sigmoid(x: float) -> float:
    try:
        return 1.0 / (1.0 + math.exp(-x))
    except OverflowError:
        return 0.0 if x < 0 else 1.0

def _softmax(vec: list[float]) -> list[float]:
    m = max(vec)
    exps = [math.exp(v - m) for v in vec]
    total = sum(exps)
    return [e / total for e in exps]

def _dot(w: list[float], x: list[float]) -> float:
    return sum(wi * xi for wi, xi in zip(w, x))

def _forward_layer(W, b, x, activation=_relu) -> list[float]:
    return [activation(_dot(W[i], x) + b[i]) for i in range(len(W))]


# ── Feature encoding ──────────────────────────────────────────────────────────

def _build_feature_vector(req: dict) -> list[float]:
    """
    Convert a preprocessed request into the fixed 7-element feature vector.
    Order: [Role, RequestType, Severity, TimeSensitivity, CrowdLevel, Distance, Eligibility]
    """
    role       = ROLE_ENCODING.get(req.get("role", "student"), 0)
    req_type   = REQUEST_TYPE_ENCODING.get(req.get("category", "AI_Lab_Support"), 0)
    severity   = float(req.get("severity",         5))
    time_sens  = float(req.get("time_sensitivity", 5))
    crowd      = float(req.get("crowd_level",      5))
    distance   = float(req.get("distance",         4))
    eligibility = 1.0 if req.get("eligibility_claim", True) else 0.0

    # Normalise numeric features to roughly [0, 1] range
    return [
        float(role) / 2.0,
        float(req_type) / 4.0,
        severity  / 10.0,
        time_sens / 10.0,
        crowd     / 10.0,
        distance  / 10.0,
        eligibility,
    ]


# ── Perceptron (binary classifier) ───────────────────────────────────────────

def _perceptron_predict(x: list[float]) -> str:
    """
    Binary Perceptron: urgent vs not_urgent.
    Uses a step activation: 1 if weighted_sum + bias > 0.
    """
    z = _dot(PERCEPTRON_WEIGHTS, x) + PERCEPTRON_BIAS
    return "urgent" if z > 0 else "not_urgent"


# ── MLP (multiclass classifier) ───────────────────────────────────────────────

def _mlp_predict(x: list[float]) -> tuple[str, float]:
    """
    2-hidden-layer MLP for multiclass priority prediction.
    Returns (label, confidence).
    """
    h1  = _forward_layer(W1, B1, x, _relu)
    h2  = _forward_layer(W2, B2, h1, _relu)
    raw = [_dot(W3[i], h2) + B3[i] for i in range(4)]
    probs = _softmax(raw)
    best  = probs.index(max(probs))
    return PRIORITY_LABELS[best], round(probs[best], 4)


# ── Public API ────────────────────────────────────────────────────────────────

def predict_priority(req: dict) -> dict:
    """
    Run both ANN models on the request and return a combined priority output.

    Returns
    -------
    dict with keys:
        binary_priority  : "urgent" | "not_urgent"
        final_priority   : "low" | "normal" | "high" | "urgent"
        confidence       : float  (0-1, softmax confidence of MLP)
        feature_vector   : list   (the 7-element input vector, for transparency)
    """
    x = _build_feature_vector(req)
    binary   = _perceptron_predict(x)
    label, conf = _mlp_predict(x)

    return {
        "binary_priority": binary,
        "final_priority":  label,
        "confidence":      conf,
        "feature_vector":  [round(v, 4) for v in x],
    }
