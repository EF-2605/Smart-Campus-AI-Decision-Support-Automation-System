"""
Module: Final Response Layer
─────────────────────────────
Responsibility:
  - Aggregate outputs from all executed modules
  - Build one coherent, user-facing response object
  - Only include fields for modules that actually ran

Output structure matches FINAL_RESPONSE_TEMPLATE from project spec.
"""


def build_final_response(
    req: dict,
    pipeline: dict,
    priority_out:  dict | None,
    logic_out:     dict | None,
    csp_out:       dict | None,
    search_out:    dict | None,
    early_reject:  bool = False,
) -> dict:
    """
    Combine module outputs into the final response object.

    Parameters
    ----------
    req          : preprocessed request dict
    pipeline     : router output with pipeline flags
    priority_out : ANN output dict or None
    logic_out    : Logic/KB output dict or None
    csp_out      : CSP output dict or None
    search_out   : Search output dict or None
    early_reject : True if Logic/KB denied access before CSP ran

    Returns
    -------
    dict — final response (matches FINAL_RESPONSE_TEMPLATE)
    """
    request_type = req.get("request_type", "")
    name         = req.get("name", "User")

    # ── Determine top-level decision ──────────────────────────────────────
    if request_type == "Eligibility_Check":
        decision = "answered"
    elif early_reject:
        decision = "rejected"
    elif csp_out and csp_out.get("decision") == "rejected":
        decision = "rejected"
    elif request_type == "Navigation_Only":
        decision = "completed"
    else:
        decision = "accepted"

    # ── Build sub-sections ────────────────────────────────────────────────
    priority_section   = {}
    eligibility_section = {}
    assignment_section  = {}
    route_section       = {}

    # Priority (ANN)
    if priority_out:
        priority_section = {
            "binary_priority": priority_out.get("binary_priority", ""),
            "final_priority":  priority_out.get("final_priority", ""),
            "confidence":      priority_out.get("confidence", 0.0),
            "feature_vector":  priority_out.get("feature_vector", []),
        }

    # Eligibility / Logic-KB
    if logic_out:
        if request_type == "Eligibility_Check":
            eligibility_section = {
                "entailed":    logic_out.get("entailed", False),
                "explanation": logic_out.get("explanation", ""),
                "chain":       logic_out.get("chain", []),
            }
        else:
            eligibility_section = {
                "allowed":     logic_out.get("allowed", False),
                "explanation": logic_out.get("explanation", ""),
            }

    # CSP assignment
    if csp_out and csp_out.get("decision") == "accepted":
        assignment_section = {
            "room":  csp_out.get("assigned_room", ""),
            "slot":  csp_out.get("assigned_slot"),
            "notes": csp_out.get("notes", ""),
        }

    # Route
    if search_out and not search_out.get("error"):
        route_section = {
            "algorithm": search_out.get("algorithm_used", ""),
            "path":      search_out.get("path", []),
            "cost":      search_out.get("cost", 0),
            "steps":     search_out.get("steps", 0),
        }

    # ── Compose human-readable message ────────────────────────────────────
    msg = _compose_message(
        name, decision, request_type,
        priority_out, logic_out, csp_out, search_out, early_reject,
    )

    return {
        "request_id":  req.get("request_id", ""),
        "decision":    decision,
        "pipeline":    pipeline.get("selected_pipeline", []),
        "priority":    priority_section,
        "eligibility": eligibility_section,
        "assignment":  assignment_section,
        "route":       route_section,
        "message":     msg,
    }


def _compose_message(
    name, decision, request_type,
    priority_out, logic_out, csp_out, search_out, early_reject,
) -> str:
    """Build the human-readable summary message."""
    parts = []

    if decision == "answered":
        entailed = logic_out.get("entailed", False) if logic_out else False
        if entailed:
            parts.append(f"✅ Query answered: the fact is entailed from the Knowledge Base.")
        else:
            parts.append("❌ Query answered: the fact cannot be derived from the Knowledge Base.")

    elif early_reject:
        reason = logic_out.get("explanation", "Access denied by Logic/KB.") if logic_out else "Access denied."
        parts.append(f"❌ Request for {name} was rejected: {reason}")

    elif decision == "rejected" and csp_out:
        parts.append(f"❌ No available slot could be found. {csp_out.get('notes', '')}")

    elif decision == "accepted":
        parts.append(f"✅ Request for {name} has been accepted.")
        if priority_out:
            p = priority_out.get("final_priority", "").upper()
            c = int(priority_out.get("confidence", 0) * 100)
            parts.append(f"Priority assigned: {p} (confidence {c}%).")
        if csp_out and csp_out.get("assigned_room"):
            room = csp_out["assigned_room"].replace("_", " ")
            slot = csp_out["assigned_slot"]
            parts.append(f"Booked: {room}, Slot {slot}.")
        if search_out and not search_out.get("error"):
            algo = search_out.get("algorithm_used", "")
            path = search_out.get("path", [])
            cost = search_out.get("cost", 0)
            if path:
                dest = path[-1].replace("_", " ")
                parts.append(f"Route to {dest} computed via {algo} (cost: {cost} units).")

    elif decision == "completed":
        if search_out and not search_out.get("error"):
            algo = search_out.get("algorithm_used", "")
            path = search_out.get("path", [])
            cost = search_out.get("cost", 0)
            steps = search_out.get("steps", 0)
            parts.append(f"✅ Route computed via {algo}: {steps} hops, total cost {cost} units.")
        else:
            err = search_out.get("error", "Unknown error.") if search_out else "Search failed."
            parts.append(f"❌ Navigation failed: {err}")

    return " ".join(parts) if parts else "Request processed."
