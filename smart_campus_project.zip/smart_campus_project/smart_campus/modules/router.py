"""
Module: Request Router
──────────────────────
Responsibility:
  - Read the request_type from the preprocessed request object
  - Decide which AI modules must run and in which order
  - Return a pipeline control object (dict) with boolean flags

The router does NOT solve requests. It only decides the execution path.
Pipeline definitions (from project spec):
  Navigation_Only       → Search
  Eligibility_Check     → Logic/KB
  Booking_or_Scheduling → Logic/KB → CSP → optional Search
  Urgent_Service_Request→ ANN → Logic/KB → CSP → optional Search
  Full_Service_Request  → ANN → Logic/KB → CSP → Search
"""


def route_request(req: dict) -> dict:
    """
    Inspect the preprocessed request and determine the module pipeline.

    Parameters
    ----------
    req : dict
        Preprocessed, validated request object.

    Returns
    -------
    dict
        Pipeline control object with flags and ordered pipeline list.
    """
    rt = req.get("request_type", "")

    if rt == "Navigation_Only":
        pipeline = ["Search"]
        needs = dict(needs_ann=False, needs_logic=False, needs_csp=False, needs_search=True)

    elif rt == "Eligibility_Check":
        pipeline = ["Logic_KB"]
        needs = dict(needs_ann=False, needs_logic=True, needs_csp=False, needs_search=False)

    elif rt == "Booking_or_Scheduling":
        # Search is optional — include it only when current_location is given
        has_location = bool(req.get("current_location"))
        pipeline = ["Logic_KB", "CSP"] + (["Search"] if has_location else [])
        needs = dict(needs_ann=False, needs_logic=True, needs_csp=True, needs_search=has_location)

    elif rt == "Urgent_Service_Request":
        has_location = bool(req.get("current_location"))
        pipeline = ["ANN", "Logic_KB", "CSP"] + (["Search"] if has_location else [])
        needs = dict(needs_ann=True, needs_logic=True, needs_csp=True, needs_search=has_location)

    elif rt == "Full_Service_Request":
        pipeline = ["ANN", "Logic_KB", "CSP", "Search"]
        needs = dict(needs_ann=True, needs_logic=True, needs_csp=True, needs_search=True)

    else:
        # Unknown type — should have been caught in preprocessing
        pipeline = []
        needs = dict(needs_ann=False, needs_logic=False, needs_csp=False, needs_search=False)

    return {
        "request_id":       req["request_id"],
        "selected_pipeline": pipeline,
        **needs,   # needs_ann, needs_logic, needs_csp, needs_search
    }
