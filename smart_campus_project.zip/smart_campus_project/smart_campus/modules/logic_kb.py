"""
Module: Logic / Knowledge Base
───────────────────────────────
Responsibility:
  - Act as the rule-based reasoning / gatekeeper of the system
  - For Eligibility_Check: answer whether a query is entailed from the KB
  - For all other request types: check whether the user is allowed to proceed
  - If not allowed → stop the pipeline (early_reject = True in app.py)

Knowledge Base contains:
  - Facts:  Teaches(DrKhan, AI), Student(Ali), Enrolled(Ali, AI), etc.
  - Rules:  FOL-style implications, e.g. Teaches(x, AI) → Instructor(x, AI)

This module uses forward-chaining to entail facts.
"""

from typing import Any

# ─────────────────────────────────────────────────────────────────────────────
# Knowledge Base — Facts
# ─────────────────────────────────────────────────────────────────────────────
FACTS: set[str] = {
    # Roles
    "Student(Ali)",
    "Student(Sara)",
    "Student(Zain)",
    "Instructor(DrKhan, AI)",
    "Instructor(DrKhan, Lab1)",
    "Staff(Ahmad)",

    # Teaching
    "Teaches(DrKhan, AI)",

    # Enrolment
    "Enrolled(Ali, AI)",
    "Enrolled(Sara, AI)",
    "Enrolled(Zain, DataScience)",

    # Completed prerequisites
    "Completed(Ali, ProgrammingFundamentals)",
    "Completed(Sara, ProgrammingFundamentals)",

    # Lab access grants
    "Enrolled(Ali, AI)",          # → eligible for AI_Lab_Support
}

# ─────────────────────────────────────────────────────────────────────────────
# Knowledge Base — Rules
# Represented as (antecedent_template, consequent_template, explanation)
# ─────────────────────────────────────────────────────────────────────────────
RULES = [
    # Rule R1: Teaches(x, AI) → Instructor(x, AI) (if not already)
    {
        "name": "R1",
        "antecedent": lambda facts, args: f"Teaches({args[0]}, AI)" in facts,
        "consequent": lambda args: f"Instructor({args[0]}, AI)",
        "explanation": lambda args: f"Teaches({args[0]}, AI) ∧ R1 ⊢ Instructor({args[0]}, AI)",
    },
    # Rule R2: Instructor(x, AI) → UsesLab(x, Lab1)
    {
        "name": "R2",
        "antecedent": lambda facts, args: f"Instructor({args[0]}, AI)" in facts,
        "consequent": lambda args: f"UsesLab({args[0]}, Lab1)",
        "explanation": lambda args: f"Instructor({args[0]}, AI) ∧ R2 ⊢ UsesLab({args[0]}, Lab1)",
    },
    # Rule R3: Enrolled(x, AI) → UsesLab(x, Lab1)
    {
        "name": "R3",
        "antecedent": lambda facts, args: f"Enrolled({args[0]}, AI)" in facts,
        "consequent": lambda args: f"UsesLab({args[0]}, Lab1)",
        "explanation": lambda args: f"Enrolled({args[0]}, AI) ∧ R3 ⊢ UsesLab({args[0]}, Lab1)",
    },
    # Rule R4: Student(x) ∧ Completed(x, ProgrammingFundamentals) → Eligible(x, AI)
    {
        "name": "R4",
        "antecedent": lambda facts, args: (
            f"Student({args[0]})" in facts and
            f"Completed({args[0]}, ProgrammingFundamentals)" in facts
        ),
        "consequent": lambda args: f"Eligible({args[0]}, AI)",
        "explanation": lambda args: (
            f"Student({args[0]}) ∧ Completed({args[0]}, ProgrammingFundamentals) "
            f"∧ R4 ⊢ Eligible({args[0]}, AI)"
        ),
    },
    # Rule R5: Enrolled(x, AI) → Eligible(x, AI_Lab_Support)
    {
        "name": "R5",
        "antecedent": lambda facts, args: f"Enrolled({args[0]}, AI)" in facts,
        "consequent": lambda args: f"Eligible({args[0]}, AI_Lab_Support)",
        "explanation": lambda args: f"Enrolled({args[0]}, AI) ∧ R5 ⊢ Eligible({args[0]}, AI_Lab_Support)",
    },
]


def _forward_chain(query_fact: str, subject: str) -> tuple[bool, list[str]]:
    """
    Forward chaining: apply all rules iteratively until the KB stabilises.
    Returns (entailed: bool, explanation_chain: list[str]).
    """
    working_facts = set(FACTS)
    chain = []
    changed = True
    while changed:
        changed = False
        for rule in RULES:
            new_fact = rule["consequent"]([subject])
            if new_fact not in working_facts and rule["antecedent"](working_facts, [subject]):
                working_facts.add(new_fact)
                chain.append(rule["explanation"]([subject]))
                changed = True

    return (query_fact in working_facts, chain)


def _parse_query(query: str) -> tuple[str, list[str]]:
    """
    Parse a FOL-style query string like "UsesLab(DrKhan, Lab1)".
    Returns (predicate, args_list).
    """
    query = query.strip()
    if "(" not in query:
        return query, []
    pred = query[:query.index("(")]
    inner = query[query.index("(") + 1: -1]
    args = [a.strip() for a in inner.split(",")]
    return pred, args


def _check_eligibility_query(req: dict) -> dict:
    """
    Handle Eligibility_Check: try to entail the requested query from the KB.
    """
    query = req.get("query", "").strip()
    if not query:
        return {"entailed": False, "explanation": "No query provided."}

    pred, args = _parse_query(query)
    subject = args[0] if args else req.get("name", "Unknown")

    # Try direct fact lookup first
    if query in FACTS:
        return {
            "entailed": True,
            "explanation": f"'{query}' is a direct fact in the Knowledge Base.",
            "chain": [f"Fact: {query}"],
        }

    # Forward chain
    entailed, chain = _forward_chain(query, subject)

    if entailed:
        explanation = f"{' → '.join(chain)}" if chain else f"Derived from KB rules."
    else:
        explanation = (
            f"'{query}' cannot be entailed from the current Knowledge Base. "
            f"Required facts or prerequisites may be missing."
        )

    return {
        "entailed": entailed,
        "explanation": explanation,
        "chain": chain,
    }


def _check_access(req: dict) -> dict:
    """
    For non-eligibility requests: decide whether the user's role and
    enrolment/credentials allow this service category.
    """
    name     = req.get("name", "Unknown")
    role     = req.get("role", "student")
    category = req.get("category", "")
    subject  = name  # used in FOL queries

    # ── Role-based base rules ─────────────────────────────────────────────
    if role == "staff":
        return {
            "allowed": True,
            "explanation": f"Staff member '{name}' has unrestricted service access by default.",
            "chain": ["Role(staff) → AllAccess"],
        }

    # ── Category-specific checks ──────────────────────────────────────────
    allowed = False
    explanation = ""
    chain = []

    if category == "AI_Lab_Support":
        target_fact = f"Eligible({subject}, AI_Lab_Support)"
        allowed, chain = _forward_chain(target_fact, subject)
        if allowed:
            explanation = f"{name} is enrolled in AI and is eligible for AI Lab Support."
        else:
            explanation = (
                f"{name} is NOT eligible for AI Lab Support. "
                f"Must be enrolled in AI course."
            )

    elif category == "Viva_Scheduling":
        # Any enrolled student or instructor is allowed
        enrolled = f"Enrolled({subject}, AI)" in FACTS or f"Enrolled({subject}, DataScience)" in FACTS
        is_instructor = role == "instructor"
        allowed = enrolled or is_instructor
        explanation = (
            f"{name} is allowed for Viva Scheduling (enrolled/instructor)."
            if allowed else
            f"{name} is not enrolled in any course eligible for viva scheduling."
        )

    elif category == "Access_Request":
        # Instructors always allowed; students need enrolment
        if role == "instructor":
            allowed = True
            explanation = f"Instructor '{name}' has access request privilege."
        else:
            target_fact = f"UsesLab({subject}, Lab1)"
            allowed, chain = _forward_chain(target_fact, subject)
            explanation = (
                f"{name} is allowed lab access (enrolled in AI)."
                if allowed else
                f"{name} does not have lab access permissions."
            )

    elif category == "Maintenance":
        # Only staff (handled above) or instructors
        allowed = role == "instructor"
        explanation = (
            f"Instructor '{name}' can request maintenance."
            if allowed else
            f"Students cannot raise maintenance requests."
        )

    elif category == "Emergency_Help":
        # Anyone can request emergency help
        allowed = True
        explanation = f"Emergency Help is available to all campus users."

    else:
        explanation = f"Unknown category '{category}'."

    return {
        "allowed": allowed,
        "explanation": explanation,
        "chain": chain,
    }


# ── Public API ────────────────────────────────────────────────────────────────

def check_logic(req: dict) -> dict:
    """
    Main entry point for the Logic/KB module.

    For Eligibility_Check → run forward-chaining entailment on the query.
    For all other types   → run access/permission check.

    Returns
    -------
    dict  (either eligibility result or access result)
    """
    if req.get("request_type") == "Eligibility_Check":
        return _check_eligibility_query(req)
    else:
        return _check_access(req)
