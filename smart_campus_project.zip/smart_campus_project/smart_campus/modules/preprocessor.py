"""
Module: Input & Preprocessing
─────────────────────────────
Responsibility:
  - Validate all incoming request fields (types, ranges, required presence)
  - Normalize string values to the project's standard naming convention
  - Build one clean, standard request object (dict) for all downstream modules
  - Set module-need flags so the router has clean data to work with

Returns: (request_dict, error_string_or_None)
"""

import uuid
import math

# ── Known campus nodes ───────────────────────────────────────────────────────
VALID_LOCATIONS = {
    "main_gate", "parking", "admin_block", "student_services", "exam_hall",
    "seminar_room", "library", "ai_lab", "science_block", "cafeteria",
    "medical_center", "bus_stop", "hostel",
}

# Alias map: user-typed variants → canonical name
LOCATION_ALIASES = {
    "main gate":       "Main_Gate",
    "main_gate":       "Main_Gate",
    "parking":         "Parking",
    "admin block":     "Admin_Block",
    "admin_block":     "Admin_Block",
    "adminblock":      "Admin_Block",
    "student services":"Student_Services",
    "student_services":"Student_Services",
    "exam hall":       "Exam_Hall",
    "exam_hall":       "Exam_Hall",
    "seminar room":    "Seminar_Room",
    "seminar_room":    "Seminar_Room",
    "library":         "Library",
    "ai lab":          "AI_Lab",
    "ai_lab":          "AI_Lab",
    "ailab":           "AI_Lab",
    "science block":   "Science_Block",
    "science_block":   "Science_Block",
    "cafeteria":       "Cafeteria",
    "medical center":  "Medical_Center",
    "medical_center":  "Medical_Center",
    "bus stop":        "Bus_Stop",
    "bus_stop":        "Bus_Stop",
    "hostel":          "Hostel",
}

VALID_ROLES = {"student", "instructor", "staff"}
VALID_REQUEST_TYPES = {
    "Navigation_Only", "Eligibility_Check",
    "Booking_or_Scheduling", "Urgent_Service_Request", "Full_Service_Request",
}
VALID_CATEGORIES = {
    "AI_Lab_Support", "Viva_Scheduling", "Access_Request",
    "Maintenance", "Emergency_Help",
}
CATEGORY_ALIASES = {
    "ai lab support":   "AI_Lab_Support",
    "ai_lab_support":   "AI_Lab_Support",
    "viva scheduling":  "Viva_Scheduling",
    "viva_scheduling":  "Viva_Scheduling",
    "access request":   "Access_Request",
    "access_request":   "Access_Request",
    "maintenance":      "Maintenance",
    "emergency help":   "Emergency_Help",
    "emergency_help":   "Emergency_Help",
}

# ── Weighted distances from Hostel (used as distance proxy for ANN) ──────────
DISTANCE_FROM_HOSTEL = {
    "Hostel": 0, "Cafeteria": 3, "Medical_Center": 3, "Bus_Stop": 2,
    "Science_Block": 6, "AI_Lab": 7, "Library": 7, "Parking": 5,
    "Main_Gate": 4, "Admin_Block": 5, "Student_Services": 7,
    "Exam_Hall": 8, "Seminar_Room": 9,
}


def _normalize_location(raw: str) -> str | None:
    """Convert a user-typed location to the canonical campus node name."""
    key = raw.strip().lower().replace("-", "_")
    return LOCATION_ALIASES.get(key, None)


def _normalize_role(raw: str) -> str | None:
    r = raw.strip().lower()
    return r if r in VALID_ROLES else None


def _normalize_request_type(raw: str) -> str | None:
    # Accept both "Full_Service_Request" and "full_service_request" etc.
    mapping = {rt.lower(): rt for rt in VALID_REQUEST_TYPES}
    return mapping.get(raw.strip().lower(), None)


def _normalize_category(raw: str) -> str | None:
    key = raw.strip().lower().replace("-", "_")
    if key in CATEGORY_ALIASES:
        return CATEGORY_ALIASES[key]
    # direct match after title-casing
    for c in VALID_CATEGORIES:
        if c.lower() == key:
            return c
    return None


def _safe_int(val, lo, hi, default=5) -> int:
    try:
        v = int(val)
        return max(lo, min(hi, v))
    except (TypeError, ValueError):
        return default


def preprocess_request(raw: dict) -> tuple[dict, str | None]:
    """
    Validate and normalise the raw frontend request.

    Parameters
    ----------
    raw : dict
        Raw JSON body from the frontend.

    Returns
    -------
    (request_dict, error)
        error is None on success, or a human-readable string on failure.
    """
    # ── Required base fields ──────────────────────────────────────────────
    name = str(raw.get("name", "")).strip()
    if not name:
        return {}, "Field 'name' is required."

    role_raw = str(raw.get("role", ""))
    role = _normalize_role(role_raw)
    if not role:
        return {}, f"Invalid role '{role_raw}'. Must be: student / instructor / staff."

    rt_raw = str(raw.get("request_type", ""))
    request_type = _normalize_request_type(rt_raw)
    if not request_type:
        return {}, f"Invalid request_type '{rt_raw}'."

    # ── Generate request_id ───────────────────────────────────────────────
    request_id = raw.get("request_id") or f"REQ-{str(uuid.uuid4())[:8].upper()}"

    # ── Type-specific validation ──────────────────────────────────────────
    current_location_raw = str(raw.get("current_location", ""))
    destination_raw      = str(raw.get("destination", ""))
    category_raw         = str(raw.get("category", ""))

    current_location = _normalize_location(current_location_raw) if current_location_raw else ""
    destination      = _normalize_location(destination_raw)      if destination_raw      else ""
    category         = _normalize_category(category_raw)         if category_raw         else ""

    if request_type == "Navigation_Only":
        if not current_location:
            return {}, f"Navigation_Only requires a valid 'current_location'. Got: '{current_location_raw}'."
        if not destination:
            return {}, f"Navigation_Only requires a valid 'destination'. Got: '{destination_raw}'."

    if request_type == "Eligibility_Check":
        query = str(raw.get("query", "")).strip()
        if not query:
            return {}, "Eligibility_Check requires a 'query' field."
    else:
        query = str(raw.get("query", "")).strip()

    if request_type in ("Booking_or_Scheduling", "Urgent_Service_Request", "Full_Service_Request"):
        if not category:
            return {}, f"Request type '{request_type}' requires a valid 'category'. Got: '{category_raw}'."
        if not current_location:
            return {}, f"Request type '{request_type}' requires a valid 'current_location'. Got: '{current_location_raw}'."

    # ── Numeric fields ────────────────────────────────────────────────────
    preferred_slot    = _safe_int(raw.get("preferred_slot",    1), 1, 4, default=1)
    severity          = _safe_int(raw.get("severity",          5), 1, 10, default=5)
    time_sensitivity  = _safe_int(raw.get("time_sensitivity",  5), 1, 10, default=5)
    crowd_level       = _safe_int(raw.get("crowd_level",       5), 1, 10, default=5)

    # ── Compute distance for ANN feature vector ───────────────────────────
    distance = DISTANCE_FROM_HOSTEL.get(current_location, 5)

    # ── Build standard request object ────────────────────────────────────
    req = {
        "request_id":       request_id,
        "name":             name,
        "role":             role,
        "request_type":     request_type,
        "category":         category,
        "current_location": current_location,
        "destination":      destination,
        "preferred_slot":   preferred_slot,
        "severity":         severity,
        "time_sensitivity": time_sensitivity,
        "crowd_level":      crowd_level,
        "distance":         distance,
        "group_id":         str(raw.get("group_id", "")).strip(),
        "query":            query,
        "eligibility_claim": bool(raw.get("eligibility_claim", True)),
        "description_note": str(raw.get("description_note", "")).strip(),
    }

    return req, None
