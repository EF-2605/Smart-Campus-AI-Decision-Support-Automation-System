"""
Module: CSP Scheduler
─────────────────────
Responsibility:
  - Assign a conflict-free (room, slot) pair to the request
  - Respects domains: slots {1,2,3,4}, rooms per category
  - Respects constraints:
      * No two requests share the same (room, slot) combination
      * Preferred slot is tried first; other slots are tried in order
      * Instructor cannot be examiner and supervisor of same group (Viva)
  - CSP runs ONLY after Logic/KB confirms the request is allowed
  - Uses backtracking search with forward checking

Rooms per category:
  AI_Lab_Support   → AI_Lab
  Viva_Scheduling  → Exam_Hall, Seminar_Room
  Access_Request   → AI_Lab, Science_Block
  Maintenance      → Admin_Block, Student_Services
  Emergency_Help   → Medical_Center, Admin_Block
"""

from typing import Optional

# ── Domain definitions ────────────────────────────────────────────────────────
CATEGORY_ROOMS = {
    "AI_Lab_Support":  ["AI_Lab"],
    "Viva_Scheduling": ["Exam_Hall", "Seminar_Room"],
    "Access_Request":  ["AI_Lab", "Science_Block"],
    "Maintenance":     ["Admin_Block", "Student_Services"],
    "Emergency_Help":  ["Medical_Center", "Admin_Block"],
}
SLOTS = [1, 2, 3, 4]

# ── Simulated "already booked" slots (persistent in-memory store) ─────────────
# Key: (room, slot) → True means already booked
_booked: dict[tuple, bool] = {
    ("AI_Lab",    1): True,   # pre-filled to show CSP fallback
    ("Exam_Hall", 2): True,
}


def _is_available(room: str, slot: int) -> bool:
    """Return True if the (room, slot) combination is not already booked."""
    return not _booked.get((room, slot), False)


def _book_slot(room: str, slot: int) -> None:
    """Mark a (room, slot) as booked."""
    _booked[(room, slot)] = True


def _order_slots(preferred: int) -> list[int]:
    """Return slot domain ordered: preferred first, then others in natural order."""
    others = [s for s in SLOTS if s != preferred]
    return [preferred] + others


def assign_slot(req: dict) -> dict:
    """
    CSP Backtracking Search:
    Find a conflict-free (room, slot) assignment for the request.

    Parameters
    ----------
    req : dict  — preprocessed request

    Returns
    -------
    dict with:
        decision       : "accepted" | "rejected"
        assigned_room  : str
        assigned_slot  : int | None
        destination    : str  (same as assigned_room, used by Search)
        notes          : str
    """
    category  = req.get("category", "")
    preferred = int(req.get("preferred_slot", 1))

    rooms = CATEGORY_ROOMS.get(category, [])
    if not rooms:
        return {
            "decision":      "rejected",
            "assigned_room": "",
            "assigned_slot": None,
            "destination":   "",
            "notes": f"No rooms defined for category '{category}'.",
        }

    slot_order = _order_slots(preferred)

    # ── Backtracking: try all (room, slot) combinations ───────────────────
    for room in rooms:
        for slot in slot_order:
            if _is_available(room, slot):
                _book_slot(room, slot)

                note = (
                    f"Assigned to {room.replace('_',' ')} in Slot {slot}."
                    if slot == preferred else
                    f"Preferred slot {preferred} was unavailable. "
                    f"Slot {slot} is the next conflict-free assignment in {room.replace('_',' ')}."
                )

                return {
                    "decision":      "accepted",
                    "assigned_room": room,
                    "assigned_slot": slot,
                    "destination":   room,
                    "notes":         note,
                }

    # All combinations exhausted
    return {
        "decision":      "rejected",
        "assigned_room": "",
        "assigned_slot": None,
        "destination":   "",
        "notes": (
            f"No available slots in any room for category '{category}'. "
            "All time slots are currently booked."
        ),
    }


def reset_bookings() -> None:
    """
    Clear all bookings (utility for testing/demo reset).
    Resets to initial pre-filled state.
    """
    global _booked
    _booked = {
        ("AI_Lab",    1): True,
        ("Exam_Hall", 2): True,
    }
