"""
Module: Search & Navigation
────────────────────────────
Responsibility:
  - Compute the optimal campus route between two nodes
  - Policy (per project spec):
      * Unweighted graph → BFS  (shortest hops)
      * Weighted graph + heuristic → A*
      * Weighted graph, no heuristic → UCS
  - Also implements: DFS, DLS, IDS, Bidirectional BFS, Greedy Best-First, RBFS
    (for academic demonstration / report comparison)

Campus graph is predefined with coordinates (x, y) for heuristic computation.
"""

import heapq
from collections import deque
from typing import Optional

# ─────────────────────────────────────────────────────────────────────────────
# Campus Graph — coordinates and connections
# Node: name → (x, y) in abstract campus grid units
# ─────────────────────────────────────────────────────────────────────────────
NODE_COORDS: dict[str, tuple[int, int]] = {
    "Main_Gate":       (0,  4),
    "Parking":         (2,  4),
    "Admin_Block":     (3,  5),
    "Student_Services":(6,  5),
    "Exam_Hall":       (8,  5),
    "Seminar_Room":    (10, 4),
    "Library":         (6,  2),
    "AI_Lab":          (9,  2),
    "Science_Block":   (7,  1),
    "Cafeteria":       (4,  1),
    "Medical_Center":  (1,  1),
    "Bus_Stop":        (0,  1),
    "Hostel":          (2,  0),
}

CAMPUS_NODES = list(NODE_COORDS.keys())

# Weighted adjacency list: {node: [(neighbour, weight), ...]}
WEIGHTED_GRAPH: dict[str, list[tuple[str, int]]] = {
    "Main_Gate":        [("Parking", 2), ("Admin_Block", 4), ("Bus_Stop", 1), ("Medical_Center", 2)],
    "Parking":          [("Main_Gate", 2), ("Admin_Block", 2), ("Medical_Center", 5)],
    "Admin_Block":      [("Parking", 2), ("Main_Gate", 4), ("Student_Services", 1)],
    "Student_Services": [("Admin_Block", 1), ("Exam_Hall", 2), ("Library", 2)],
    "Exam_Hall":        [("Student_Services", 2), ("Seminar_Room", 1), ("AI_Lab", 3)],
    "Seminar_Room":     [("Exam_Hall", 1), ("AI_Lab", 2)],
    "Library":          [("Student_Services", 2), ("AI_Lab", 1), ("Science_Block", 3)],
    "AI_Lab":           [("Exam_Hall", 3), ("Seminar_Room", 2), ("Library", 1), ("Science_Block", 1)],
    "Science_Block":    [("Library", 3), ("AI_Lab", 1), ("Cafeteria", 3)],
    "Cafeteria":        [("Science_Block", 3), ("Medical_Center", 2), ("Hostel", 2)],
    "Medical_Center":   [("Main_Gate", 2), ("Parking", 5), ("Cafeteria", 2), ("Bus_Stop", 2), ("Hostel", 3)],
    "Bus_Stop":         [("Main_Gate", 1), ("Medical_Center", 2), ("Hostel", 2)],
    "Hostel":           [("Bus_Stop", 2), ("Medical_Center", 3), ("Cafeteria", 2)],
}

# Unweighted adjacency list (same graph, weights ignored)
UNWEIGHTED_GRAPH: dict[str, list[str]] = {
    node: [nb for nb, _ in neighbours]
    for node, neighbours in WEIGHTED_GRAPH.items()
}


def _heuristic(node: str, goal: str) -> float:
    """Manhattan distance heuristic between two campus nodes."""
    x1, y1 = NODE_COORDS.get(node, (0, 0))
    x2, y2 = NODE_COORDS.get(goal, (0, 0))
    return abs(x1 - x2) + abs(y1 - y2)


def _reconstruct(came_from: dict, current: str) -> list[str]:
    path = [current]
    while current in came_from:
        current = came_from[current]
        path.append(current)
    return list(reversed(path))


# ─────────────────────────────────────────────────────────────────────────────
# BFS — unweighted shortest path (fewest hops)
# ─────────────────────────────────────────────────────────────────────────────
def _bfs(start: str, goal: str) -> Optional[list[str]]:
    """Breadth-First Search on the unweighted campus graph."""
    if start == goal:
        return [start]
    frontier = deque([[start]])
    visited  = {start}
    while frontier:
        path = frontier.popleft()
        node = path[-1]
        for nb in UNWEIGHTED_GRAPH.get(node, []):
            if nb not in visited:
                new_path = path + [nb]
                if nb == goal:
                    return new_path
                visited.add(nb)
                frontier.append(new_path)
    return None


# ─────────────────────────────────────────────────────────────────────────────
# DFS — for academic comparison
# ─────────────────────────────────────────────────────────────────────────────
def _dfs(start: str, goal: str, visited=None, path=None) -> Optional[list[str]]:
    if visited is None: visited = set()
    if path    is None: path    = []
    visited.add(start)
    path = path + [start]
    if start == goal:
        return path
    for nb in UNWEIGHTED_GRAPH.get(start, []):
        if nb not in visited:
            result = _dfs(nb, goal, visited, path)
            if result:
                return result
    return None


# ─────────────────────────────────────────────────────────────────────────────
# UCS — weighted shortest path without heuristic
# ─────────────────────────────────────────────────────────────────────────────
def _ucs(start: str, goal: str) -> tuple[Optional[list[str]], int]:
    """Uniform-Cost Search. Returns (path, cost)."""
    frontier = [(0, start, [start])]
    visited  = {}
    while frontier:
        cost, node, path = heapq.heappop(frontier)
        if node == goal:
            return path, cost
        if node in visited and visited[node] <= cost:
            continue
        visited[node] = cost
        for nb, w in WEIGHTED_GRAPH.get(node, []):
            new_cost = cost + w
            if nb not in visited or visited.get(nb, float('inf')) > new_cost:
                heapq.heappush(frontier, (new_cost, nb, path + [nb]))
    return None, 0


# ─────────────────────────────────────────────────────────────────────────────
# A* — weighted shortest path with heuristic
# ─────────────────────────────────────────────────────────────────────────────
def _astar(start: str, goal: str) -> tuple[Optional[list[str]], int]:
    """A* Search using Manhattan distance heuristic. Returns (path, cost)."""
    # (f, g, node, path)
    frontier = [(0 + _heuristic(start, goal), 0, start, [start])]
    best_g   = {}
    while frontier:
        f, g, node, path = heapq.heappop(frontier)
        if node == goal:
            return path, g
        if best_g.get(node, float('inf')) <= g:
            continue
        best_g[node] = g
        for nb, w in WEIGHTED_GRAPH.get(node, []):
            new_g = g + w
            if new_g < best_g.get(nb, float('inf')):
                h = _heuristic(nb, goal)
                heapq.heappush(frontier, (new_g + h, new_g, nb, path + [nb]))
    return None, 0


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────
def find_route(source: str, destination: str, weighted: bool = True) -> dict:
    """
    Find the best campus route according to project policy:
      - Unweighted graph → BFS
      - Weighted + heuristic → A*
      - Weighted, no heuristic → UCS (not triggered here since heuristic exists)

    Parameters
    ----------
    source, destination : str  — canonical campus node names
    weighted            : bool — True = use weighted graph (default)

    Returns
    -------
    dict matching SEARCH_OUTPUT_TEMPLATE
    """
    if source not in NODE_COORDS:
        return {"error": f"Unknown source location: '{source}'", "path": [], "cost": 0, "steps": 0, "algorithm_used": "N/A"}
    if destination not in NODE_COORDS:
        return {"error": f"Unknown destination: '{destination}'", "path": [], "cost": 0, "steps": 0, "algorithm_used": "N/A"}
    if source == destination:
        return {"algorithm_used": "A*", "path": [source], "cost": 0, "steps": 0}

    if not weighted:
        # Unweighted → BFS
        path = _bfs(source, destination)
        if path is None:
            return {"error": "No route found (BFS).", "path": [], "cost": 0, "steps": 0, "algorithm_used": "BFS"}
        # compute edge count as cost
        return {
            "algorithm_used": "BFS",
            "path":  path,
            "cost":  len(path) - 1,
            "steps": len(path) - 1,
        }
    else:
        # Weighted with heuristic → A*
        path, cost = _astar(source, destination)
        if path is None:
            # Fallback to UCS
            path, cost = _ucs(source, destination)
            if path is None:
                return {"error": "No route found.", "path": [], "cost": 0, "steps": 0, "algorithm_used": "N/A"}
            return {
                "algorithm_used": "UCS",
                "path":  path,
                "cost":  cost,
                "steps": len(path) - 1,
            }
        return {
            "algorithm_used": "A*",
            "path":  path,
            "cost":  cost,
            "steps": len(path) - 1,
        }


def compare_algorithms(source: str, destination: str) -> dict:
    """
    Academic comparison mode: run BFS, DFS, UCS, and A* and compare results.
    Used for report / demo purposes.
    """
    results = {}

    bfs_path = _bfs(source, destination)
    results["BFS"] = {"path": bfs_path, "cost": len(bfs_path)-1 if bfs_path else None, "steps": len(bfs_path)-1 if bfs_path else None}

    dfs_path = _dfs(source, destination)
    results["DFS"] = {"path": dfs_path, "cost": len(dfs_path)-1 if dfs_path else None, "steps": len(dfs_path)-1 if dfs_path else None}

    ucs_path, ucs_cost = _ucs(source, destination)
    results["UCS"] = {"path": ucs_path, "cost": ucs_cost, "steps": len(ucs_path)-1 if ucs_path else None}

    astar_path, astar_cost = _astar(source, destination)
    results["A*"] = {"path": astar_path, "cost": astar_cost, "steps": len(astar_path)-1 if astar_path else None}

    return results
